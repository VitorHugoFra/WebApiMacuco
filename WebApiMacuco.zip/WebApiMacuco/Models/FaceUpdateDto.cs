﻿namespace WebApiMacuco.Models
{
    public class FaceUpdateDto
    {
        public int Id { get; set; }
        public string Description { get; set; } = string.Empty;
    }
}
